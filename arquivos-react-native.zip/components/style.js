import { StyleSheet } from 'react-native';

export default StyleSheet.create({
    fontBig: {
        fontSize: 16,
        textAlign: 'center'
    },
})